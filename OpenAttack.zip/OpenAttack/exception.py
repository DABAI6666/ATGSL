class AttackException(Exception):
    pass
